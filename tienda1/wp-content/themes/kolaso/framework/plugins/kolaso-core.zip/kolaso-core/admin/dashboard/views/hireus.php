<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly. ?>

<div class="col">
<div class="col-wrap">
<p>Are you looking for theme customization services? get it directly from our professional developers.</p>
<a href="https://zytheme.com/studio/" class="button button-large button-primary avada-large-button" target="_blank">Visit Studio</a>
</div>
</div>