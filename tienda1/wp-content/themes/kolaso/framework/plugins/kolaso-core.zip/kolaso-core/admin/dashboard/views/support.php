<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly. ?>

<p>We are provide support forum for clients. You can join to support forum for submit any question after purchasing.</p>

<p><a href="https://zytheme.com/support" class="button" target="_blank" rel="nofollow"><i class="fa fa-life-ring"></i> Support Forum</a> -(or)- <a href="http://themeforest.net/user/zytheme/" class="button" target="_blank" rel="nofollow"><i class="fa fa-link"></i> themeforest profile</a></p>
