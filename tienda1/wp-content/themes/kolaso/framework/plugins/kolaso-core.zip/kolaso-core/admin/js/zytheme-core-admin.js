(function ($) {
	'use strict';

})(jQuery);