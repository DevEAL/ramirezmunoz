<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly. ?>

<p>If you are new to kolaso, here is a step-by-step plan for getting started.</p>

<p><a href="https://zytheme.com/kolaso/documentation/" class="button" target="_blank" rel="nofollow"><i class="fa fa-book"></i> Online Documentation</a></p>

<h4><span class="dashicons dashicons-book"></span>Knowledgebase</h4>
<p>We have a growing library of high-definititon tutorials to help teach you the different aspects of using WordPress.</p>
<p><a href="https://zytheme.com/" class="button" target="_blank">Knowledgebase</a></p>
